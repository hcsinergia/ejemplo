#http://josearcosaneas.github.io/python/xls/csv/2016/12/26/leer-excel-csv.html


import csv

f = open('fh2.csv')
#lines = csv.reader(f)
#Cambiar el tipo de separador a ; ,
lines = csv.reader(f,delimiter=';')
for line in lines:
    #print(str(line[0]), str(line[1]), str(line[2]), str(line[3]))
     print(str(line[0]))