from django.conf import settings
from django.shortcuts import redirect
import google.oauth2.credentials
import google_auth_oauthlib.flow


# Client configuration for an OAuth 2.0 web server application
# (cf. https://developers.google.com/identity/protocols/OAuth2WebServer)
# CLIENT_CONFIG = {'web': {
#     'client_id': settings.GOOGLE_CLIENT_ID,
#     'project_id': settings.GOOGLE_PROJECT_ID,
#     'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
#     'token_uri': 'https://www.googleapis.com/oauth2/v3/token',
#     'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
#     'client_secret': settings.GOOGLE_CLIENT_SECRET,
#     'redirect_uris': settings.GOOGLE_REDIRECT_URIS,
#     'javascript_origins': settings.GOOGLE_JAVASCRIPT_ORIGINS}}

CLIENT_CONFIG = {'web': {
    'client_id': 'gestion',
    'project_id': '4b8e75c914cf21ce5111fbcc403e1bce656fb09a',
    'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
    'token_uri': 'https://www.googleapis.com/oauth2/v3/token',
    'token_uri': 'https://oauth2.googleapis.com/token',
    'auth_provider_x509_cert_url': 'https://www.googleapis.com/robot/v1/metadata/x509/gestion%40appspot.gserviceaccount.com',
    'client_secret': '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCb3HmRwBpiKTvX\nuAvX1NMl6wg4+54S+fiaKRVZ+Nc7Hs6W4NgnoTqsq9u8g/6+xgxwdhLKPiCvQjfP\nDnRyDokDWhyl7vKlVzyDnDSh+Nx9J3kdxMMhnjZgCL+4HosI+57r9Hzx5W5IPvRS\niOH9W5eKjijcVe4CjFIs2rzX8YPyVo2Y0t3p7TnYHv9HQOlSY4PB9lHh/ZafJSfq\nEHzPaxXGBiM7efBktlKSBtCPw++jX6m2iIoHjW3oXdxkjEGVSatrk6hMyy/jrsuJ\nITUfZtVSifQ4Cb5BKu2M/oME1mn+3c4UDf42az7xvcam8N1eG08dAmGDLB3QPODl\nKM8KxeELAgMBAAECggEAFpssUM0Fpp4nbVrm8NeQBoxn5WftXgA+pBF4ZNPYV91Y\nhn63K0xRx9CnbtjQPphYHompoQbQ08qtcI0+q3pbOg68X/7f18Zm4wnpgmKnjEmI\n4h3zVXFunpA2Sny3msZwHvYXlzg5PiZPZpcu/AHoYXLMD2UxP9Jdat8RC9seUawt\nIKNOpcko8bQp7YcEuVgTKvcFLFI7D2Yo62SoT7r75FOL4kYlFFoXmGAcD6vXaeMV\nFBdGqrwGufzvTHlK/C/x9fOhlQs9UepgGYbrO5PDMC7HRvJhtmshC/Ej5iMfWK7c\nz3R2SqdgQYCLo7RhsDGsk5eK2aQ+T3qzOJQZGz3uQQKBgQDP7kUrvya+BVGpOc7r\nn/YiM/PDHRQnus8YAShwX1awuJE7DQE8YO09tBvWGYCb57Py+b2GCS9EcgOQovgd\nlzqyFmkFiAGjRfyz1vrwBxWpoNRERO4N/TV+WdJNNCrg/g1U1+Ls6xLsAvbtCydo\n/mKoN0Z59ZG70HN8nlxs4eOBywKBgQC/5KI11YO2r79a4bIwiM9DqM1SxPtVINGr\noL2cr/sWyz8eWJ5ztxsoU3FQ1ov1tUZKKEgbVGjeTw4OzG4BnVJJM57b5lXr3piT\nBOWZhrXm3xqn1kzje0tZAZYVU/LMDhl8XTFWBWYPxKW4WsJ0iJEppN2ZA98WSbbR\nHSPJGOY1wQKBgFZOvbF555fqV0oZ77TIMf9idyUe9dXD6eA54tI6EJ7MDaRoMoIg\nbXk2QHOvJD4SgBQz66IuP8t2U9p+euS1eCyhtrgQCzX9f/YaHxDwr+I4GsO3pORz\nnPe0SuG27LF1Yo08CzpyHOmQFXSxM4uWQ9c1EnDfKL2/uaAZj522aZvfAoGBAJat\nrCXDi9J2vDZbxPTRaJbDRL66iHQ2+gzfgiQ4F1y1qdFlWr6YSE3o/7CvV2VPu2rd\nqIk1RcdSokJCihrgcs2iKBqaClvVBU9kZ/meytUH2UFzSBrUJL02Pqhuq9dJNv/t\nmaDnSlYVXt+c/NZOqlXd7FeLr7Arn88iJ4hv8czBAoGBAM4topZGNJnJrKVpaQPA\nNZPsuIDN0CMr/9n7hMlv5v1WyPR62pp+b345jvKsSpAhlyirWxjxskev0G4jVuXr\nFqJ4/Sn88Pyg9GLE/s4MKdBucEv+tJk26xscNgm46OsNUrsYHY0bf8emy1jEU3lM\n8SIlEgDc7s/kBOYqGzTQOg5n\n-----END PRIVATE KEY-----\n',
    
}}


# This scope will allow the application to manage your calendars
SCOPES = ['https://www.googleapis.com/auth/calendar']

get_authorization_url()

def get_authorization_url():

    # Use the information in the client_secret.json to identify
    # the application requesting authorization.
    flow = google_auth_oauthlib.flow.Flow.from_client_config(
        client_config=CLIENT_CONFIG,
        scopes=SCOPES)



    # Indicate where the API server will redirect the user after the user completes
    # the authorization flow. The redirect URI is required.
    flow.redirect_uri = 'http://localhost:8000'

    # Generate URL for request to Google's OAuth 2.0 server.
    # Use kwargs to set optional request parameters.
    authorization_url, state = flow.authorization_url(
        # Enable offline access so that you can refresh an access token without
        # re-prompting the user for permission. Recommended for web server apps.
        access_type='offline',
        # Enable incremental authorization. Recommended as a best practice.
        include_granted_scopes='true'),
    return authorization_url, state



