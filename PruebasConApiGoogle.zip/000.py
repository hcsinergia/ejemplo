from __future__ import print_function
from apiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools

try:
    import argparse
    flag=argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flag = None

# SCOPES = 'https://www.googleapis.com/auth/calendar'
# store = file.Storage('storage.json')
# creds = store.get()
# if not creds or creds.invalid:
#     flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
#     creds = tools.run_flow(flow, store)

# try:
#     import argparse
#     flags = argparse.ArgumentParser(parents[tools.argparser]).parse_args()
# except ImportError:
#     flags = None

SCOPES = 'https://www.googleapis.com/auth/calendar'
store = file.Storage('storage.json')
creds = store.get()
if not creds or creds.invalid:
    flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
    creds = tools.run_flow(flow, store, flags) \
          if flags else tools.run(flow, store)


CAL = build('calendar', 'v3', http=creds.authorize(Http()))

GMT_OFF = '-07:00'
#TIMEZONE = 'America/Argentina/Buenos_Aires'
EVENT = {
    'summary':'Prueba Escribiendo Eventos',
    'start':  {'dateTime': '2018-12-20T19:00:00%s' % GMT_OFF},#'timeZone': TIMEZONE},
    'end':    {'dateTime': '2018-12-20T22:00:00%s' % GMT_OFF},#'timeZone': TIMEZONE},
    'attendees': [
        {'email' : 'email1@email.com'},
        {'email2' : 'emil2@gmail.com'},
    ],
    #'recurrence': ['RRULE:FREQ=MONTHLY;INTERVAL=2;UNTIL=20171231']
}

#EVENT_ID = YOUR_EVENT_ID_STR_HERE
# e = GCAL.events().patch(calendarId='primary', eventId=EVENT_ID,
#         sendNotifications=True, body=EVENT).execute()
e = CAL.events().insert(calendarId='primary',
        sendNotifications=True, body=EVENT).execute()

created_calendar = CAL.calendars().insert(body=new_calendar).execute()

print('''*** %r event added:
    Start: %s
    End:   %s ''' % (e['summary'].encode('utf-8'),
                  e['start']['dateTime'], e['end']['dateTime']))