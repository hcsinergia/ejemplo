from __future__ import print_function
from apiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools
import csv

from datetime import datetime
#from dateutil.parser import parse as dtparse
#from datetime import datetime as dt


import csv
f = open('fh2.csv')
#lines = csv.reader(f)
#Cambiar el tipo de separador a ; ,

try:
    import argparse
    flag=argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flag = None



lines = csv.reader(f,delimiter=';')
COUNT = 0
for line in lines:
    #print(str(line[0]), str(line[1]), str(line[2]), str(line[3]))
    #print(str(line[2]))
    SCOPES = 'https://www.googleapis.com/auth/calendar'
    store = file.Storage('storage.json')
    creds = store.get()
    if not creds or creds.invalid:
    	flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
    	creds = tools.run_flow(flow, store)

    dato_inicio = str(line[2])
    dato_fin = str(line[3])
    #format_str = datetime.date(dato_inicio, "%Y-%m-%d %H:%M:%S")
    #print(inicio+'-03:00')
    print(dato_inicio+'-03:00')
    print(dato_inicio+'-03:00')
    #from datetime import datetime, timezone, timedelta
	#datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").replace(
    #tzinfo=timezone(timedelta(0)))

    COUNT = COUNT + 1
    event1 = {
        'summary': str(line[0]),
        'location': str(line[1]),
        'start': {
            'dateTime': dato_inicio + '-03:00',
            'timeZone' : 'America/Argentina/Buenos_Aires',
        },
        'end': {
            'dateTime': dato_fin +'-03:00',
            'timeZone' : 'America/Argentina/Buenos_Aires',
        },   
        #cada dos dias
        # 'recurrence' : [
        #     'RRULE:FREQ=DAILY;COUNT=2' 
        # ],
        'reminders':{
            'useDefault': False,
            'overrides': [
                {'method' : 'email', 'minutes': 24 * 60},
                {'method' : 'popup', 'minutes' : 10},
            ],
        },
    }
    print('===========================')
    service = build('calendar', 'v3', http=creds.authorize(Http()))
    event1 = service.events().insert(calendarId='primary', body=event1).execute()
    print('Evento Creado: %s' % (event1.get('htmlLink')))	

