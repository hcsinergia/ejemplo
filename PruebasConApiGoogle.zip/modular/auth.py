from __future__ import print_function
import httplib2
import os

from apiclient import discovery
from oauth2client import file, client, tools
from oauth2client.file import Storage

try:
    import argparse
    flag = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
	flag = None

	class ClassName(object):
		"""docstring for ClassName"""
		def __init__(self, SCOPES,CLIENT_SECRET_FILE, APPLICATION_NAME):
			self.SCOPES = SCOPES
			self.CLIENT_SECRET_FILE = CLIENT_SECRET_FILE
			self.APPLICATION_NAME = CLIENT_SECRET_FILE
		def function(self):
			cmd_dir = os.getcmd()
			credential_dir = os.path.join(cmd_dir, '.credeintials')
			if not os.path.exists(credeintial_dir):
				credential_path = os.path.join(credeintial_dir,
					'client_secret.jon')

			store = Storage(credential_path)
			credeintials = store.get()
			if not credeintials or credeintials.invalid:
				fllw = client.flow_clientsecrets(self.CLIENT_SECRET_FILE, self.SCOPES)
				flow.user_agent = self.APPLICATION_NAME
				if flags:
					credeintials = tools.run_flow(flow, store, flags)
				else:
					credeintials = tools.run_flow(flow, store)
				print('Guardando credencial para ' + credential_path)
				return credencial
			