from __future__ import print_function
import httplib2
import os

from apiclient import discovery
from oauth2client import file, client, tools
from oauth2client.file import Storage

try:
    import argparse
    flag = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
	flag = None
import auth

SCOPES = 'https://www.googleapis.com/auth/calendar'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'Gestion'
authInst = auth(SCOPES, CLIENT_SECRET_FILE, APPLICATION_NAME)
credentials = authInst.getCredentials()

http = credentials.authorize(httplib2.Http())
calendar_service = build('calendar', 'v3', http=creds.authorize(Http()))

def crearEvento():
	event1 = {
    'summary':'Evento para Mica',
    'location': 'Diag 74, 202, La Plata, Buenos Aires, Argentina',
    'start': {
        #'dateTime': '2018-12-21T09:00:00-07:00',
        'dateTime': '2018-12-26T10:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },
    'end': {
        'dateTime': '2018-12-26T12:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },   
    #cada dos dias
    # 'recurrence' : [
    #     'RRULE:FREQ=DAILY;COUNT=2' 
    # ],
    'reminders':{
        'useDefault': False,
        'overrides': [
            {'method' : 'email', 'minutes': 24 * 60},
            {'method' : 'popup', 'minutes' : 10},
        ],
    },
}

event1 = calendar_service.events().insert(calendarId='primary', body=event1).execute()
print('Event created: %s' % (event1.get('htmlLink')))
