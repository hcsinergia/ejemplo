

from __future__ import print_function
from apiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools

#https://developers.google.com/calendar/v3/reference/events
#Doc fecha y hora internacional
#https://tools.ietf.org/html/rfc3339
#https://es.wikipedia.org/wiki/ISO_8601

try:
    import argparse
    flag=argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flag = None

SCOPES = 'https://www.googleapis.com/auth/calendar'
store = file.Storage('storage.json')
creds = store.get()
if not creds or creds.invalid:
    flow = client.flow_from_clientsecrets('client_secret.json', SCOPES)
    creds = tools.run_flow(flow, store)
service = build('calendar', 'v3', http=creds.authorize(Http()))

#GMT_OFF = '-07:00' #argentina -3
#TIMEZONE = 'America/Argentina/Buenos_Aires'
event1 = {
    'summary':'Evento para Mica',
    'location': 'Diag 74, 202, La Plata, Buenos Aires, Argentina',
    'start': {
        #'dateTime': '2018-12-21T09:00:00-07:00',
        'dateTime': '2018-12-22T10:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },
    'end': {
        'dateTime': '2018-12-22T12:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },   
    #cada dos dias
    # 'recurrence' : [
    #     'RRULE:FREQ=DAILY;COUNT=2' 
    # ],
    'reminders':{
        'useDefault': False,
        'overrides': [
            {'method' : 'email', 'minutes': 24 * 60},
            {'method' : 'popup', 'minutes' : 10},
        ],
    },
}
event2 = {
    'summary':'Prueba Escribiendo Eventos',
    'location': 'Diag 74, 202, La Plata, Buenos Aires, Argentina',
    'start': {
        #'dateTime': '2018-12-21T09:00:00-07:00',
        'dateTime': '2018-12-22T14:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },
    'end': {
        'dateTime': '2018-12-22T16:00:00-03:00',
        'timeZone' : 'America/Argentina/Buenos_Aires',
    },   
    #cada dos dias
    # 'recurrence' : [
    #     'RRULE:FREQ=DAILY;COUNT=2' 
    # ],
    # 'attendees': [
    #         {'email': 'hcsinergia@gmail.com.com'},
    #       ],
    'reminders':{
        'useDefault': False,
        'overrides': [
            {'method' : 'email', 'minutes': 24 * 60},
            {'method' : 'popup', 'minutes' : 10},
        ],
    },
}

event1 = service.events().insert(calendarId='primary', body=event1).execute()
print('Event created: %s' % (event1.get('htmlLink')))
event2 = service.events().insert(calendarId='primary', body=event2).execute()
print('Event created: %s' % (event2.get('htmlLink')))


